/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package voicetodolist;
import java.util.Scanner;

public class VoiceToDoList {

    static Scanner scanner = new Scanner(System.in);
    static User currentUser = new User("Student_Group_1", "English");
    static int idCounter = 1; // auto assign ID

    public static void main(String[] args) {
        // examples
        addManualTask("Buy groceries", "High", "Monday");
        addManualTask("Submit assignment", "Medium", "Tuesday");

        char ch;
        boolean session = true;

        while (session) {

            System.out.println("\n==========================================");
            System.out.println("   VOICE-CONTROLLED TO-DO LIST MANAGER");
            System.out.println("==========================================");
            System.out.println(" [A] - Add Task (Simulate Voice Command)");
            System.out.println(" [L] - List All Tasks");
            System.out.println(" [U] - Update Task Status/Details");
            System.out.println(" [D] - Delete Task");
            System.out.println(" [V] - View Full Details");
            System.out.println(" [S] - Add/View Subtasks");
            System.out.println(" [X] - Exit");
            System.out.println("==========================================");
            System.out.print("Enter choice: ");

            String input = scanner.next();
            ch = input.toUpperCase().charAt(0);
            scanner.nextLine();

            switch (ch) {
                case 'A':
                    addTaskVoice();
                    break;
                case 'L':
                    listTasks();
                    break;
                case 'U':
                    updateTask();
                    break;
                case 'D':
                    deleteTask();
                    break;
                case 'V':
                    viewTaskDetails();
                    break;
                case 'S':
                    addViewSubtasks();
                    break;
                case 'X':
                    System.out.println("Exiting system...");
                    session = false;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // 1. LINKED LIST INSERTION (The "Voice" Feature)

    static void addTaskVoice() {
        System.out.println("\n--- SIMULATE VOICE INPUT ---");
        System.out.println("Try saying: 'Buy Milk Priority High on Friday'");
        System.out.print("🎤 Enter your command: ");
        String voiceInput = scanner.nextLine();

        String extractedPriority = "Low"; // Default
        String extractedDate = "Today"; // Default
        String extractedName = voiceInput; // Assume whole string is name initially

        if (voiceInput.toLowerCase().contains("priority high")) {
            extractedPriority = "High";
            extractedName = extractedName.replaceAll("(?i)priority high", "");
        } else if (voiceInput.toLowerCase().contains("priority medium")) {
            extractedPriority = "Medium";
            extractedName = extractedName.replaceAll("(?i)priority medium", "");
        }

        if (voiceInput.toLowerCase().contains("on monday"))
            extractedDate = "Monday";
        else if (voiceInput.toLowerCase().contains("on tuesday"))
            extractedDate = "Tuesday";
        else if (voiceInput.toLowerCase().contains("on friday"))
            extractedDate = "Friday";

        extractedName = extractedName.replaceAll("(?i)on [a-z]+", "").trim();

        // 2. Create the New Node
        Task newTask = new Task(idCounter++, voiceInput, extractedName, extractedPriority, extractedDate);

        // 3. Insert into Linked List (Insertion at End)
        if (currentUser.head == null) {
            currentUser.head = newTask;
        } else {
            Task current = currentUser.head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newTask;
        }

        System.out.println("✅ AI Processed: Task '" + extractedName + "' added successfully!");
    }

    // Helper method to add tasks without typing (for pre-populating)
    static void addManualTask(String name, String prio, String date) {
        Task newTask = new Task(idCounter++, "Manual Entry", name, prio, date);
        if (currentUser.head == null) {
            currentUser.head = newTask;
        } else {
            Task current = currentUser.head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newTask;
        }
    }

    // 2. LINKED LIST TRAVERSAL (Display)

    static void listTasks() {
        if (currentUser.head == null) {
            System.out.println("\n[!] The list is empty.");
            return;
        }

        Task current = currentUser.head;
        System.out.println("\n--- YOUR TO-DO LIST ---");
        System.out.printf("%-5s %-20s %-10s %-10s %-10s\n", "ID", "Task Name", "Priority", "Date", "Status");
        System.out.println("-------------------------------------------------------------");

        while (current != null) {
            String status = current.isCompleted ? "[DONE]" : "[ ]";
            System.out.printf("%-5d %-20s %-10s %-10s %-10s\n",
                    current.taskID,
                    current.taskName,
                    current.priority,
                    current.dueDate,
                    status);

            current = current.next;
        }
        System.out.println("-------------------------------------------------------------");
    }

    // 3. LINKED LIST MODIFICATION (Update)

    static void updateTask() {
        listTasks();
        System.out.print("\nEnter ID of task to update: ");
        int searchId = scanner.nextInt();
        scanner.nextLine();

        Task current = currentUser.head;
        boolean found = false;

        while (current != null) {
            if (current.taskID == searchId) {
                found = true;
                System.out.println("Found Task: " + current.taskName);
                System.out.println("1. Mark as Completed");
                System.out.println("2. Change Priority");
                System.out.print("Enter choice: ");
                int updateChoice = scanner.nextInt();

                if (updateChoice == 1) {
                    current.isCompleted = true;
                    System.out.println("✅ Task marked as completed.");
                } else if (updateChoice == 2) {
                    System.out.print("Enter new priority (High/Medium/Low): ");
                    current.priority = scanner.next();
                    System.out.println("✅ Priority updated.");
                }
                break;
            }
            current = current.next;
        }

        if (!found) {
            System.out.println("❌ Task ID not found.");
        }
    }

    // 4. LINKED LIST DELETION (Delete)

    static void deleteTask() {
        if (currentUser.head == null) {
            System.out.println("List is empty.");
            return;
        }

        listTasks();
        System.out.print("\nEnter ID of task to delete: ");
        int deleteId = scanner.nextInt();

        Task current = currentUser.head;
        Task prev = null;

        // Case 1: Deleting the Head
        if (current != null && current.taskID == deleteId) {
            currentUser.head = current.next; // Move head
            System.out.println("✅ Task deleted successfully.");
            return;
        }

        // Case 2: Searching for the node
        while (current != null && current.taskID != deleteId) {
            prev = current;
            current = current.next;
        }

        // Case 3: Node not found
        if (current == null) {
            System.out.println("❌ Task ID not found.");
            return;
        }

        // Case 4: Unlink the node
        prev.next = current.next;
        System.out.println("✅ Task deleted successfully.");
    }

    // --------------------------------------------------------
    // NEW FEATURE: VIEW ALL 16 VARIABLES (Satisfies Rubric for "Access")
    // --------------------------------------------------------
    static void viewTaskDetails() {
        if (currentUser.head == null) {
            System.out.println("List is empty.");
            return;
        }

        System.out.print("\nEnter Task ID to view full details: ");
        int searchId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        Task current = currentUser.head;
        boolean found = false;

        while (current != null) {
            if (current.taskID == searchId) {
                found = true;
                System.out.println("\n===========================================");
                System.out.println("   📝 FULL TASK DETAILS (Using all 16 Variables)");
                System.out.println("===========================================");

                // 1. Identification
                System.out.println("[ID]:             " + current.taskID);

                // 2. Voice Data (These are the ones you were worried about!)
                System.out.println("[Raw Command]:    " + current.rawVoiceCommand);
                System.out.println("[AI Confidence]:  " + current.voiceConfidenceScore + "%");
                System.out.println("[Audio Path]:     " + current.audioFilePath);
                System.out.println("[Language]:       " + current.detectedLanguage);

                // 3. Task Details
                System.out.println("[Task Name]:      " + current.taskName);
                System.out.println("[Category]:       " + current.category);
                System.out.println("[Priority]:       " + current.priority);
                System.out.println("[Extra Notes]:    " + current.extraNotes);

                // 4. Time & Scheduling
                System.out.println("[Due Date]:       " + current.dueDate);
                System.out.println("[Due Time]:       " + current.dueTime);
                System.out.println("[Est. Duration]:  " + current.estimatedDuration + " mins");
                System.out.println("[Recurring]:      " + (current.isRecurring ? "Yes" : "No"));

                // 5. Context & Status
                System.out.println("[Location]:       " + current.location);
                System.out.println("[Status]:         " + (current.isCompleted ? "Completed" : "Pending"));
                System.out.println("[Created By]:     " + current.createdBy + " on " + current.creationDate);
                System.out.println("===========================================");
                break;
            }
            current = current.next;
        }
        if (!found)
            System.out.println("❌ Task ID not found.");
    }




        // SUBTASKS
    static void addViewSubtasks() {
        System.out.println("\n--- ADD/VIEW SUBTASKS ---");

        System.out.println("Enter Task ID: ");
        int taskID = scanner.nextInt();
        scanner.nextLine(); // consume newline

        Task current = currentUser.head;
        boolean found = false;

        while (current != null) {
            if (current.taskID == taskID) {
                found = true;
                break;
            }
            current = current.next;
        }
        if (!found) {
            System.out.println("❌ Task ID not found.");
            return;
        }

        boolean subtasksesh = true;
        while (subtasksesh) {
            System.out.println("\n[A] - Add Subtask");
            System.out.println("[D] - Delete Subtask");
            System.out.println("[V] - View Subtasks");
            System.out.println("[X] - Exit");
            System.out.print("Enter choice: ");
            
            String input = scanner.next();
            char choice = input.toUpperCase().charAt(0);
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 'A':
                    addSubtask(current); // Pass current
                    break;
                case 'D':
                    removeSubtask(current); // Pass current
                    break;
                case 'V':
                    listSubtasks(current); // Pass current
                    break;
                case 'X':
                    subtasksesh = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // 1. STACK INSERTION (Add)
    static void addSubtask(Task current) { // Accept current
        System.out.print("Enter a subtask for " + current.taskName + " : ");
        String subtask = scanner.nextLine();

        SubTask newsubtask = new SubTask(subtask);

        if (current.subtaskdetail == null) {
            current.subtaskdetail = newsubtask;
        } else {
            newsubtask.next = current.subtaskdetail; // Use next, not ptrnext
            current.subtaskdetail = newsubtask;
        }
        System.out.println("✅ Subtask added.");
    }

    // 2. STACK DELETION (Delete/Pop)
    static void removeSubtask(Task current) { // Accept current
        if (current.subtaskdetail == null) {
            System.out.println("\n\nThe list is empty. Nothing to delete!!!");
        } else {
            System.out.println("Completed: " + current.subtaskdetail.subtaskdetail);
            current.subtaskdetail = current.subtaskdetail.next; // Use next
        }
    }

    // 3. STACK DISPLAY (List)
    static void listSubtasks(Task current) { // Accept current
        if (current.subtaskdetail == null) {
            System.out.println("\nEmpty list");
            return;
        }

        SubTask currentNode = current.subtaskdetail;
        System.out.println("\n--- SUBTASKS FOR " + current.taskName + " ---");
        while (currentNode != null) {
            System.out.println("- " + currentNode.subtaskdetail);
            currentNode = currentNode.next; // Use next
        }
    }


    
}
